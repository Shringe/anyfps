package me.jellysquid.mods.sodium.client.util.workarounds.probe;

public record GraphicsAdapterInfo(GraphicsAdapterVendor vendor, String name, String version) {

}
