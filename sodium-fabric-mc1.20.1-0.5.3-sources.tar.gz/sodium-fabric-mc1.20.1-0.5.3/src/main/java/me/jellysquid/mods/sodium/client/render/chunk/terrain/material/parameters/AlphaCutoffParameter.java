package me.jellysquid.mods.sodium.client.render.chunk.terrain.material.parameters;

public enum AlphaCutoffParameter {
    ZERO, // 0.0f
    ONE_TENTH, // 0.1f
    HALF, // 0.5f
    ONE // 1.0f
}
