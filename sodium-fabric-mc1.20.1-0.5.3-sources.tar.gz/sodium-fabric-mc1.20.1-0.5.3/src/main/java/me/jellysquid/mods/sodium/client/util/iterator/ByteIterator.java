package me.jellysquid.mods.sodium.client.util.iterator;

public interface ByteIterator {
    boolean hasNext();

    int nextByteAsInt();
}
