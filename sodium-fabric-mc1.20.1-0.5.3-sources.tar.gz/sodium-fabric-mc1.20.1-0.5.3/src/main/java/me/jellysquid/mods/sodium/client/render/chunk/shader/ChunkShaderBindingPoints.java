package me.jellysquid.mods.sodium.client.render.chunk.shader;

public class ChunkShaderBindingPoints {
    public static final int ATTRIBUTE_PACKED_DATA = 1;

    public static final int FRAG_COLOR = 0;
}
