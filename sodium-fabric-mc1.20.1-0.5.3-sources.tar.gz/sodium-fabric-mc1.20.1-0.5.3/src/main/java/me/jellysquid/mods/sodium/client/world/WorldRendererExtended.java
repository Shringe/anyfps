package me.jellysquid.mods.sodium.client.world;

import me.jellysquid.mods.sodium.client.render.SodiumWorldRenderer;

public interface WorldRendererExtended {
    SodiumWorldRenderer sodium$getWorldRenderer();
}
