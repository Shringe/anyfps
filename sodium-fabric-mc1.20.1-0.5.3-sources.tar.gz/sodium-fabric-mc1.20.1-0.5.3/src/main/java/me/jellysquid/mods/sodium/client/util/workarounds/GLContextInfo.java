package me.jellysquid.mods.sodium.client.util.workarounds;

public record GLContextInfo(String vendor, String renderer, String version) {

}
