package me.jellysquid.mods.sodium.client.render.viewport;

public interface ViewportProvider {
    Viewport sodium$createViewport();
}
