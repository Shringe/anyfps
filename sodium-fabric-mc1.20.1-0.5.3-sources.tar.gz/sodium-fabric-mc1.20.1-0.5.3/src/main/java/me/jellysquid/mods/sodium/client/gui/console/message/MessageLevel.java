package me.jellysquid.mods.sodium.client.gui.console.message;

public enum MessageLevel {
    INFO,
    WARN,
    SEVERE
}
