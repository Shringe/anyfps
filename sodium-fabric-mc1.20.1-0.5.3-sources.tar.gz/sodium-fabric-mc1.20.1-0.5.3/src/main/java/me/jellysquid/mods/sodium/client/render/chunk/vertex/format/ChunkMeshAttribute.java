package me.jellysquid.mods.sodium.client.render.chunk.vertex.format;

public enum ChunkMeshAttribute {
    VERTEX_DATA
}
