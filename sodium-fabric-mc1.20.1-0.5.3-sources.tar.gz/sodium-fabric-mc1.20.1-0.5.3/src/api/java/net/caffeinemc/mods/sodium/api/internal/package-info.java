@ApiStatus.Internal
package net.caffeinemc.mods.sodium.api.internal;

import org.jetbrains.annotations.ApiStatus;